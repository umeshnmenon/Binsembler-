# Binsembler Package

Ensembles any number of models predictions by doing a weighted average of predictions of each of the models where weights
are a chosen metric such as Accuracy or F1 Score in the probability bins