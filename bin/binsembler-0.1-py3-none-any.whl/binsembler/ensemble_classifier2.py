from __future__ import division
import pandas as pd
import numpy as np
from binsembler.utils.common import *
from binsembler.utils.log import *
from binsembler.utils.timer import Timer
from sklearn.metrics import auc, precision_recall_curve, f1_score, roc_auc_score, roc_curve
from functools import reduce

setup_logger(log_level="INFO") #TODO: Make it configurable as a start up param


class EnsembleClassifier2:
    """
    Creates an ensemble model using the models input to the function
    1.  Based on the predicted probabilities, create bins of fixed size (say 10)
    2.  For each bin, calculate the Confusion matrix (TP, FP, TN, FN) and calculate other metrics such as Accuracy, AUC, F1 score, Precision, Recall
    3.  Repeat the steps 1 and 2 for other model
    4.  Calculate the final probability as a weighted average of models probabilities
        Select any metric as weights. For e.g. F1 Score
        (m1 F1 score * m1 predicted probability + m2 F1 score * m2 predicted probability)/ (m1 F1 score + m2 F1 score)
    """

    def __init__(self, y_pred_probs=[], y_act=[], y_preds=[], thresholds=[], nbins=10):
        """
        Initializes the class level variables
        :param y_pred_probs:
        :param y_act:
        :param y_preds:
        :param thresholds:
        :param nbins:
        """
        self._y_pred_probs = y_pred_probs
        self._y_act = y_act
        self._y_preds = y_preds
        self._thresholds = thresholds
        self._nbins = nbins
        self.bin_metrics = pd.DataFrame()
        self.threshold = 0.5
        self.pred_df = pd.DataFrame()

    @Timer(logging.getLogger())
    def train(self, metric="Accuracy"):
        """
        Here a model is nothing but binwise metric (Accuracy, F1, AUC etc.) calculated based on the probabilities provided
        :param metric: Used to calculate the Threshold
        :return:
        """
        # validations
        # predicted probabilities and actual values must be provided for all the models
        if len(self._y_pred_probs) == 0:
            assert False, "Predicted Probabilities must be provided for all the models to ensemble"

        if len(self._y_act) == 0:
            assert False, "y actual must be provided for all the models to ensemble"

        if len(self._y_pred_probs) != len(self._y_act):
            assert False, "Predicted Probabilities and actual values must be of same length"

        # Loop through each model's prediction probabilities and actual values to calculate the binwise
        length = len(self._y_pred_probs)
        if len(self._thresholds) == 0:
            self._thresholds = [0.5] * length
        model_metrics = []
        for i in range(0, length):
            y_pred_probs = self._y_pred_probs[i]
            y_act = self._y_act[i]
            y_preds = []

            if len(self._y_preds) > 0:
                if len(self._y_preds[i]) > 0:
                    y_preds = self._y_preds[i]

            threshold = self._thresholds[i]
            # do the validation inside the each model to see predicted probabilities and actual values are provided
            if len(y_pred_probs) == 0:
                assert False, "Predicted Probabilities must be provided to ensemble"

            if len(y_act) == 0:
                assert False, "y actual must be provided to ensemble"

            if len(y_pred_probs) != len(y_act):
                assert False, "Predicted Probabilities and actual values must be of same length"

            # check if preds are given, if yes attach this or derive based on threshold
            if len(y_preds) == 0:
                y_preds = np.where(np.asarray(y_pred_probs) >= threshold, 1, 0)
                #logging.info(y_preds)
                y_preds = y_preds.tolist()
                logging.info("Threshold is " + str(threshold))
                #logging.info(y_pred_probs)

            # Get probability the bins
            prob_bins = self.get_bins(y_pred_probs, self._nbins)
            # Get the confusion matrix for each bin for p1
            cm_df = self.get_cm(y_preds, y_act, prob_bins['bins'].values.tolist())
            #logging.info(cm_df.head())
            # Calculate all the metrics
            metrics_df = self.get_metrics(cm_df)
            metrics_df = metrics_df.add_prefix('m' + str(i + 1) + '_')
            #logging.info(metrics_df.head())
            model_metrics.append(metrics_df)

        bin_metrics = reduce(lambda left, right: left.join(right), model_metrics).fillna(0) #pd.merge(left, right) #pd.concat(model_metrics)
        #logging.info(bin_metrics)
        self.bin_metrics = bin_metrics
        # get the threshold for best F1
        preds_df = self._predict_prob(self._y_pred_probs, self._y_act, metric)
        # finds optimal threshold. Let's pick any of the actuals
        self.threshold = self.get_optimal_threshold(preds_df['y1_act'].values,
                                               preds_df['ensmbl_pred_probs'].values)
        return self

    @Timer(logging.getLogger())
    def predict(self, y_pred_probs=[], y_act=[], metric="Accuracy"):
        """
        Combines the predicted probabilities from any number of models as weighted average where weights are the binwise
        metric specified
        :return:
        """
        preds_df = self._predict_prob(y_pred_probs, y_act, metric)

        # predict based on threshold
        preds_df['ensmbl_preds'] = np.where(preds_df['ensmbl_pred_probs'] >= self.threshold, 1, 0)
        # ensmeble bins
        bins_df = self. get_bins(preds_df['ensmbl_pred_probs'].values, self._nbins)
        preds_df = preds_df.join(bins_df, rsuffix="pred_bin")
        self.bin_metrics = self.bin_metrics.join(bins_df)
        #logging.info(preds_df)
        logging.info(preds_df[['y1_pred_probs', 'y2_pred_probs', 'ensmbl_pred_probs']])
        #return preds_df[['ensmbl_preds', 'ensmbl_pred_probs', 'ensmbl_pred_probs0']]
        print(preds_df)
        return preds_df

    def _predict_prob(self, y_pred_probs=[], y_act=[], metric="Accuracy"):
        """
        Combines the predicted probabilities from any number of models as weighted average where weights are the binwise
        metric specified
        :return:
        """
        # make final prediction
        preds_df = pd.DataFrame()
        length = len(y_pred_probs)
        numer = [] #numerator of ensemble formula
        denom = [] #denominator of ensemble formula

        # validations
        # predicted probabilities and actual values must be provided for all the models
        if len(y_pred_probs) == 0:
            assert False, "Predicted Probabilities must be provided to predict"

        #if len(y_act) == 0:
        #    assert False, "y actual must be provided to calculate the threshold"

        for i in range(0, length):
            y_pred_probsl = y_pred_probs[i]
            y_actl = None
            if len(y_act) > 0:
                y_actl = y_act[i]

            # do the validation inside the each model to see predicted probabilities and actual values are provided
            if len(y_pred_probsl) == 0:
                assert False, "Predicted Probabilities must be provided to predict"

            #if len(y_actl) == 0:
            #    assert False, "y actual must be provided to calculate the threshold"

            prob_col_name = 'y' + str(i + 1) + '_pred_probs'
            y_col_name = 'y' + str(i + 1) + '_act'
            join_col_r = 'm' + str(i + 1) + '_bins'
            join_col_l = 'test' + str(i + 1) + '_bins'
            preds_df[prob_col_name] = y_pred_probsl
            preds_df[y_col_name] = y_actl
            # first get the bins for the new prediction probabilities
            prob_bins = self.get_bins(y_pred_probsl, self._nbins)
            prob_bins = prob_bins.add_prefix('test' + str(i + 1) + '_')
            preds_df = preds_df.join(prob_bins)
            pattern = 'm' + str(i + 1) + '_.*'
            preds_df = pd.merge(preds_df, self.bin_metrics.filter(regex=(pattern)), left_on=join_col_l,
                                right_on=join_col_r,
                                how='left')

            metricl = 'm' + str(i + 1) + '_' + metric

            # replacing na values with 0
            preds_df[metricl].fillna(0, inplace=True)
            # check if any of these metric values is zero, if yes, give a smaller value instead of zero, e.g. 0.001 to make
            # sure the the model effect is not nullified at all
            preds_df.loc[preds_df[metricl] == 0, metricl] = 0.001
            part_numer = preds_df[prob_col_name] * preds_df[metricl]
            #numer = numer + part_numer
            #denom = denom + preds_df[metricl]
            numer.append(part_numer)
            denom.append(preds_df[metricl])

        numerl = reduce(lambda left, right: left + right, numer)
        denoml = reduce(lambda left, right: left + right, denom)

        # Ensembling two models prediction
        preds_df['ensmbl_pred_probs'] = numerl / denoml
        preds_df['ensmbl_pred_probs0'] = 1 - preds_df['ensmbl_pred_probs']
        logging.info(preds_df)
        return preds_df

    def get_threshold(self):
        """
        Returs the threshold found for best F1 on the validation data set while training the ensemble
        :return:
        """
        return self.threshold

    def get_optimal_threshold(self, y, y_preds):
        """
        Calculates the optimal threshold based on roc values
        :param y_preds:
        :return:
        """
        # AUCPR
        precision, recall, thresholds = precision_recall_curve(y, y_preds)
        auprc = auc(recall, precision)
        max_f1 = 0
        for r, p, t in zip(recall, precision, thresholds):
            if p + r == 0: continue
            if (2 * p * r) / (p + r) > max_f1:
                max_f1 = (2 * p * r) / (p + r)
                max_f1_threshold = t
        logging.info('Optimal Threshold ' + str(max_f1_threshold) + ' for Maximized F1 @' + str(max_f1))
        return max_f1_threshold

    def get_cm(self, y_pred, y_act, bins):
        """
        Calculates the confusion matrix for each bin
        :param y_pred:
        :param y_act:
        :param bins:
        :return:
        """
        cm = pd.DataFrame()
        cm['y_preds'] = y_pred
        cm['y_true'] = y_act
        cm['bins'] = bins
        cm['correctly_predicted'] = np.where(cm['y_true'] == cm['y_preds'], 1, 0)
        cm['TP'] = np.where((cm['y_true'] == 1) & (cm['y_preds'] == 1), 1, 0)
        cm['TN'] = np.where((cm['y_true'] == 0) & (cm['y_preds'] == 0), 1, 0)
        cm['FP'] = np.where((cm['y_true'] == 0) & (cm['y_preds'] == 1), 1, 0)
        cm['FN'] = np.where((cm['y_true'] == 1) & (cm['y_preds'] == 0), 1, 0)
        temp = cm.groupby(['bins']).agg({'TP': 'sum', 'TN': 'sum', 'FP': 'sum', 'FN': 'sum'}).reset_index()
        return temp[['bins', 'TP', 'TN', 'FP', 'FN']]

    def get_accuracy(self, df):
        """
        Calculates the accuracy. Expects a DF object with columns TP, FP, TN, FN
        :param df:
        :return:
        """
        if (df['TP'] + df['TN'] + df['FP'] + df['FN']) == 0:
            return 0
        else:
            return (df['TP'] + df['TN']) / (df['TP'] + df['TN'] + df['FP'] + df['FN'])

    def get_precision(self, df):
        """
        Calculates the precision. Expects a DF object with columns TP, FP, TN, FN
        :param df:
        :return:
        """
        if (df['TP'] + df['FP']) == 0:
            return 0
        else:
            return df['TP'] / (df['TP'] + df['FP'])

    def get_recall(self, df):
        """
        Calculates the recall. Expects a DF object with columns TP, FP, TN, FN
        :param df:
        :return:
        """
        if (df['TP'] + df['FN']) == 0:
            return 0
        else:
            return df['TP'] / (df['TP'] + df['FN'])

    def get_f1_score(self, df):
        """
        Calculates the f1 score. Expects a DF object with columns TP, FP, TN, FN
        :param df:
        :return:
        """
        if df['Precision'] + df['Recall'] == 0:
            return 0
        else:
            return 2 * ((df['Precision'] * df['Recall']) / (df['Precision'] + df['Recall']))

    def get_metrics(self, df):
        """
        Calculates all the evaluation metrics. Expects a DF object with columns TP, FP, TN, FN
        :param df:
        :return:
        """
        df['Accuracy'] = df['F1_Score'] = df['Precision'] = df['Recall'] = df["AUC"] = df["PR_AUC"] = None
        df['Accuracy'] = df.apply(self.get_accuracy, axis=1).values.tolist()
        df['Precision'] = df.apply(self.get_precision, axis=1).values.tolist()
        df['Recall'] = df.apply(self.get_recall, axis=1).values.tolist()
        df['F1_Score'] = df.apply(self.get_f1_score, axis=1).values.tolist()
        return df

    def get_bins(self, probs, bins=10):
        """
        Splits the probs list into bins of size nbins and calculates the total counts of probs in each bin
        :param probs:
        :param nbins:
        :return: a pandas datframe with bin label and number of records in the bin
        """
        prob = [x * 100 for x in probs]
        bin_df = pd.DataFrame()
        bins_prob = [i for i in range(0, 101, bins)]
        names_prob = [str(i) + str('-') + str(i + bins) for i in range(0, 100, bins)]
        bin_df['bins'] = pd.cut(prob, bins_prob, labels=names_prob)
        bin_df['bins'] = bin_df['bins'].astype('str')
        bin_df['prob'] = prob
        temp = bin_df.groupby(['bins']).agg({'prob': 'count'}).rename(columns={'prob': 'counts'}).reset_index()
        bin_df = pd.merge(bin_df, temp, how='left', on=['bins'])
        return (bin_df)

    def get_bins_full(self, probs, nbins=10):
        """
        Splits the probs list into bins of size nbins and calculates the total counts of probs in each bin
        :param probs:
        :param nbins:
        :return: a pandas datframe with bin label and number of records in the bin
        """
        prob = [x * 100 for x in probs]
        bin_df = pd.DataFrame()
        bins_prob = [i for i in range(0, 101, nbins)]
        #names_prob = [(str(i) + str('-') + str(i + nbins), i, i + nbins) for i in range(0, 100, nbins)]
        names_prob = [str(i) + str('-') + str(i + nbins) for i in range(0, 100, nbins)]
        bin_df['bins'] = pd.cut(prob, bins_prob, labels=names_prob)
        bin_df['bins'] = bin_df['bins'].astype('str')
        bin_df['prob'] = prob
        temp = bin_df.groupby(['bins']).agg({'prob': 'count'}).rename(columns={'prob': 'counts'}).reset_index()
        temp1 = pd.DataFrame(names_prob, columns=['bins'])
        temp1 = pd.merge(temp1, temp, how='left', on=['bins']).fillna(0)
        return (temp1)
