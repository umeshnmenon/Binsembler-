class Regressor:
    """
    # TODO: Add code for regression
    """
    def __init__(self):
        """
        Class level initialization
        """
        pass
